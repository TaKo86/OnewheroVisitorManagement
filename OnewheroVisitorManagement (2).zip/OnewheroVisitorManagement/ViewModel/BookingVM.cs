﻿using OnewheroVisitorManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnewheroVisitorManagement.ViewModel
{
    public class BookingVM : Utilities.ViewModelBase
    {
        private readonly PageModel _pageModel;

        public BookingVM()
        {
            _pageModel = new PageModel();
        }
    }
}
