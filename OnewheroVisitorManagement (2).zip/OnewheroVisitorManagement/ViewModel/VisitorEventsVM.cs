﻿using OnewheroVisitorManagement.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnewheroVisitorManagement.ViewModel
{
    public class VisitorEventsVM : Utilities.ViewModelBase
    {
        private readonly PageModel _pageModel;

        public VisitorEventsVM()
        {
            _pageModel = new PageModel();
        }
    }
}
