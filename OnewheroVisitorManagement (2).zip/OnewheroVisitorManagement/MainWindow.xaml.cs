﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OnewheroVisitorManagement.ViewModel;
using OnewheroVisitorManagement.View;

namespace OnewheroVisitorManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Visitor_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new VisitorNav());
        }

        private void AdminLogin_Click(object sender, RoutedEventArgs e)
        {
            MainFrame.Navigate(new AdminLogin());
        }
    }
}