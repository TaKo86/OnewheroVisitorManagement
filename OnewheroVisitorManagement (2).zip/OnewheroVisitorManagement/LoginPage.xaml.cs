﻿using OnewheroVisitorManagement.ViewModel;
using OnewheroVisitorManagement.View;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Navigation;

namespace OnewheroVisitorManagement
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        string connectionString = "Data Source=users.db;Version=3;";
        public LoginPage()
        {
            InitializeComponent();
            EnsureDatabaseAndTable();
        }

        private void EnsureDatabaseAndTable()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string visitorTable = @"CREATE TABLE IF NOT EXISTS Visitors(
                    VisitorID INTEGER PRIMARY KEY AUTOINCREMENT, 
                    FullName TEXT NOT NULL UNIQUE, 
                    Password Text NOT NULL,
                    Contact TEXT,
                    Interests TEXT);";

                new SQLiteCommand(visitorTable, connection).ExecuteNonQuery(); //create table if it doesnt exist

                //if there is no visitor then create a default visitor
                string checkVisitor = "SELECT COUNT(*) FROM Visitors WHERE FullName='visitor';";
                using (var cmd = new SQLiteCommand(checkVisitor, connection))
                {
                    int Count = Convert.ToInt32(cmd.ExecuteScalar()); //returns first column of first row
                    if (Count == 0)
                    {
                        string insertVisitor = "INSERT INTO Visitors (FullName, Password) VALUES ('visitor', '123');";
                        new SQLiteCommand(insertVisitor, connection).ExecuteNonQuery();
                    }
                }
            }
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string fullName = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Visitors WHERE FullName=@FullName AND Password=@Password;";
                using (var cmd = new SQLiteCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@FullName", fullName);
                    cmd.Parameters.AddWithValue("@Password", password);

                    int Count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (Count > 0)
                    {
                        MessageBox.Show("Login Successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.NavigationService.Navigate(new VisitorNav());
                    }
                    else
                    {
                        MessageBox.Show("Invalid name or password", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}

