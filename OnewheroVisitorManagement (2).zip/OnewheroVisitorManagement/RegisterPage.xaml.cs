﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Navigation;
using OnewheroVisitorManagement.ViewModel;
using OnewheroVisitorManagement.View;


namespace OnewheroVisitorManagement
{
    /// <summary>
    /// Interaction logic for RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        public RegisterPage()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            if (this.DataContext != null)
            {
                this.NavigationService.Navigate(new VisitorNav());
            }
            else
            {
                MessageBox.Show("Registration failed. Please try again", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                txtFullName.Clear();
                txtEmail.Clear();
                txtPhone.Clear();
                txtPassword.Clear();
            }
        }
    }
}
