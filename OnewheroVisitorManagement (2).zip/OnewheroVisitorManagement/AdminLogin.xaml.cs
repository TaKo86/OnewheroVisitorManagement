﻿using OnewheroVisitorManagement.ViewModel;
using OnewheroVisitorManagement.View;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Navigation;

namespace OnewheroVisitorManagement
{
    /// <summary>
    /// Interaction logic for LoginPage.xaml
    /// </summary>
    public partial class AdminLogin : Page
    {
        string connectionString = "Data Source=users.db;Version=3;";
        public AdminLogin()
        {
            InitializeComponent();
            EnsureDatabaseAndTable();
        }

        private void EnsureDatabaseAndTable()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();

                string adminTable = @"CREATE TABLE IF NOT EXISTS Admins(
                    AdminID INTEGER PRIMARY KEY AUTOINCREMENT,
                    Username TEXT NOT NULL UNIQUE,
                    Password TEXT NOT NULL);";

                string visitorTable = @"CREATE TABLE IF NOT EXISTS Visitors(
                    VisitorID INTEGER PRIMARY KEY AUTOINCREMENT, 
                    FullName TEXT NOT NULL UNIQUE, 
                    Contact TEXT,
                    Interests TEXT);";

                new SQLiteCommand(adminTable, connection).ExecuteNonQuery(); //create table if it doesnt exist
                new SQLiteCommand(visitorTable, connection).ExecuteNonQuery(); //create table if it doesnt exist

                //if there is no admin then create a default admin
                string checkAdmin = "SELECT COUNT(*) FROM Admins WHERE Username='admin';";
                using (var cmd = new SQLiteCommand(checkAdmin, connection))
                {
                    int Count = Convert.ToInt32(cmd.ExecuteScalar()); //returns first column of first row
                    if (Count == 0)
                    {
                        string insertAdmin = "INSERT INTO Admins (Username, Password) VALUES ('admin', 'admin123');";
                        new SQLiteCommand(insertAdmin, connection).ExecuteNonQuery();
                    }
                }
            }
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT COUNT(*) FROM Admins WHERE Username=@Username AND Password=@Password;";
                using (var cmd = new SQLiteCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);

                    int Count = Convert.ToInt32(cmd.ExecuteScalar());
                    if (Count > 0)
                    {
                        MessageBox.Show("Login Successful!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        this.NavigationService.Navigate(new AdminNav());
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password", "Login Failed", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }
    }
}
