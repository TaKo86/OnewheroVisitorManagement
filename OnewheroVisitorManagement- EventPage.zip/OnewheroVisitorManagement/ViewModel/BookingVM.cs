﻿using OnewheroVisitorManagement.Model;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace OnewheroVisitorManagement.ViewModel
{
    public class BookingVM : Utilities.ViewModelBase
    {
        private readonly PageModel _pageModel;

        public int CurrentNum
        {
            get { return _pageModel.NumTickets; }
            set { _pageModel.NumTickets = value; }
        }

        public int eventID
        {
            get { return _pageModel.EventID; }
            set { _pageModel.EventID = value; }
        }

        public double cost, totalCost;
        public string bookingDate, eventName, costTxt, totalCostTxt;
        string connectionString = "Data Source=users.db;Version=3;";

        private void FindEvent()
        {
            foreach (Event ev in MainWindow.EventsList)
            {
                if (ev.EventID == eventID)
                {
                    cost = ev.EventCost;
                    costTxt = "Cost per Ticket: $" + cost;
                    bookingDate = ev.EventDates;
                    eventName = ev.EventName;
                    totalCostTxt = "Total Cost: " + totalCost;
                    Debug.WriteLine(bookingDate);
                    Debug.WriteLine("$" + cost);
                    Debug.WriteLine(eventName);
                }

            }
        }
        private void Decr_Click(object sender, RoutedEventArgs e)
        {
            CurrentNum--;
            if (CurrentNum <= 0)
            {
                CurrentNum = 0;
                totalCost = CurrentNum * cost;
            }
        }

        private void Incr_Click(object sender, RoutedEventArgs e)
        {
            CurrentNum++;
            Debug.Write(CurrentNum);
            totalCost = CurrentNum * cost;
        }

        private void ConfirmBook_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentNum == 0)
            {
                MessageBox.Show("Please fill in all fields.", "Input Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                Debug.Write(totalCost);
                string insertBookingQuery = "INSERT INTO Bookings (EventID, BookingDate, NumTickets, TotalCost) VALUES (@EventID, @BookingDate, @NumTickets, @TotalCost);";
                using (var insertCmd = new SQLiteCommand(insertBookingQuery, connection))
                {
                    insertCmd.Parameters.AddWithValue("@EventID", eventID);
                    insertCmd.Parameters.AddWithValue("@BookingDate", bookingDate);
                    insertCmd.Parameters.AddWithValue("@NumTickets", CurrentNum);
                    insertCmd.Parameters.AddWithValue("@TotalCost", totalCost);
                    insertCmd.ExecuteNonQuery();
                }
                MessageBox.Show($"Booking successful! Total cost: ${totalCost}", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        public BookingVM(string EventID)
        {
            _pageModel = new PageModel();
            FindEvent();
            eventID = Convert.ToInt32(EventID);
            CurrentNum = 0;
        }
    }
}
