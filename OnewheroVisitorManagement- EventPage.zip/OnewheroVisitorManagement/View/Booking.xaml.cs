﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SQLite;
using OnewheroVisitorManagement.ViewModel;
using System.Diagnostics;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Booking.xaml
    /// </summary>
    public partial class Booking : UserControl
    {
        private int _currentNum = 0;
        public Booking(string EventID)
        {
            InitializeComponent();
            FindEvent();
            eventID = Convert.ToInt32(EventID);
            txtNumTickets.Text = _currentNum.ToString();
        }
        
        int eventID, numTickets;
        double cost, totalCost;
        string bookingDate, eventName, costTxt, totalCostTxt;
        string connectionString = "Data Source=users.db;Version=3;";

        private void FindEvent()
        {
            foreach (Event ev in MainWindow.EventsList)
            {
                if (ev.EventID == eventID)
                {
                    cost = ev.EventCost;
                    costTxt = "Cost per Ticket: $" + cost;
                    bookingDate = ev.EventDates;
                    eventName = ev.EventName;
                    totalCostTxt = "Total Cost: " + totalCost;
                    Debug.WriteLine(bookingDate);
                    Debug.WriteLine("$" + cost);
                    Debug.WriteLine(eventName);
                }

            }
        }
        private void Decr_Click(object sender, RoutedEventArgs e)
        {
            _currentNum--;
            txtNumTickets.Text = _currentNum.ToString();
            if (_currentNum <= 0)
            {
                _currentNum = 0;
                txtNumTickets.Text = _currentNum.ToString();
                totalCost = _currentNum * cost;
            }
        }

        private void Incr_Click(object sender, RoutedEventArgs e)
        {
            _currentNum++;
            txtNumTickets.Text = _currentNum.ToString();
            Debug.Write(txtNumTickets.Text);
            totalCost = _currentNum * cost;        
        }

        private void ConfirmBook_Click(object sender, RoutedEventArgs e)
        { 
            if ( _currentNum == 0 )
            {
                MessageBox.Show("Please fill in all fields.", "Input Error",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }
            
            numTickets = _currentNum;
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                Debug.Write(totalCost);
                string insertBookingQuery = "INSERT INTO Bookings (EventID, BookingDate, NumTickets, TotalCost) VALUES (@EventID, @BookingDate, @NumTickets, @TotalCost);";
                using (var insertCmd = new SQLiteCommand(insertBookingQuery, connection))
                {
                    insertCmd.Parameters.AddWithValue("@EventID", eventID);
                    insertCmd.Parameters.AddWithValue("@BookingDate", bookingDate);
                    insertCmd.Parameters.AddWithValue("@NumTickets", numTickets);
                    insertCmd.Parameters.AddWithValue("@TotalCost", totalCost);
                    insertCmd.ExecuteNonQuery();
                }
                MessageBox.Show($"Booking successful! Total cost: ${totalCost}", "Success",
                                  MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
