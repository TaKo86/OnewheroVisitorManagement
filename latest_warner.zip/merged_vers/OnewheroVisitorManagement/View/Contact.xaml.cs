﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Contact.xaml
    /// </summary>
    public partial class Contact : UserControl
    {
        public Contact()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Find parent Page and execute BackCommand
            DependencyObject parent = this;
            while (parent != null && !(parent is Page))
            {
                parent = System.Windows.Media.VisualTreeHelper.GetParent(parent);
            }
            
            if (parent is Page page && page.DataContext is ViewModel.NavigationVM navVM)
            {
                navVM.BackCommand?.Execute(null);
            }
        }

        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {
            string name = txtName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string subject = txtSubject.Text.Trim();
            string message = txtMessage.Text.Trim();

            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(email) || 
                string.IsNullOrEmpty(subject) || string.IsNullOrEmpty(message))
            {
                MessageBox.Show("Please fill in all fields before sending your message.", 
                              "Incomplete Form", 
                              MessageBoxButton.OK, 
                              MessageBoxImage.Warning);
                return;
            }

            // Here you would typically send the message via email or save to database
            MessageBox.Show("Thank you for your message! We'll get back to you soon.", 
                          "Message Sent", 
                          MessageBoxButton.OK, 
                          MessageBoxImage.Information);

            // Clear the form
            txtName.Clear();
            txtEmail.Clear();
            txtSubject.Clear();
            txtMessage.Clear();
        }
    }
}
