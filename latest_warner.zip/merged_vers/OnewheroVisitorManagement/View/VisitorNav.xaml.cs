﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for VisitorNav.xaml
    /// </summary>
    public partial class VisitorNav : Page
    {
        public VisitorNav()
        {
            InitializeComponent();
            var viewModel = new ViewModel.NavigationVM("Visitor");
            this.DataContext = viewModel;
            
            // Override LogoutCommand to navigate back to MainWindow
            viewModel.LogoutCommand = new Utilities.RelayCommand(Logout);
        }
        
        private void ProfileMenuButton_Click(object sender, RoutedEventArgs e)
        {
            // Open the context menu on left-click
            if (ProfileContextMenu != null)
            {
                ProfileContextMenu.PlacementTarget = ProfileMenuButton;
                ProfileContextMenu.IsOpen = true;
            }
        }
        
        private void Logout(object obj)
        {
            // Navigate back to the initial MainWindow content (login page)
            // Find the parent MainWindow and clear its Frame
            var mainWindow = Application.Current.MainWindow as MainWindow;
            if (mainWindow != null && mainWindow.MainFrame != null)
            {
                // Clear the frame content to show the initial MainWindow content
                mainWindow.MainFrame.Content = null;
            }
        }
    }
}
