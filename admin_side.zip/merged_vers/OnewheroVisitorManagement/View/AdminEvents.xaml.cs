﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OnewheroVisitorManagement.View
{
    /// <summary>
    /// Interaction logic for Events.xaml
    /// </summary>
    public partial class AdminEvents : UserControl
    {
        string connectionString = "Data Source=users.db;Version=3;";
        
        public AdminEvents()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Find parent Page and execute BackCommand
            DependencyObject parent = this;
            while (parent != null && !(parent is Page))
            {
                parent = System.Windows.Media.VisualTreeHelper.GetParent(parent);
            }
            
            if (parent is Page page && page.DataContext is ViewModel.NavigationVM navVM)
            {
                navVM.BackCommand?.Execute(null);
            }
        }

        private void ViewTable_Click(object sender, RoutedEventArgs e)
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                string selectQuery = "SELECT * FROM Events;";
                using (var adapter = new SQLiteDataAdapter(selectQuery, connection))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridEvents.ItemsSource = dt.DefaultView;
                }
            }
        }

        private void AddEvent_Click(object sender, RoutedEventArgs e)
        {
            string eventName = txtEventName.Text.Trim();
            string eventDate = txtEventDate.Text.Trim();
            string eventDesc = txtEventDesc.Text.Trim();
            string eventCostStr = txtEventCost.Text.Trim();
            string eventImgSrc = txtEventImgSrc.Text.Trim();

            if (string.IsNullOrEmpty(eventName) || string.IsNullOrEmpty(eventDate) || 
                string.IsNullOrEmpty(eventDesc) || string.IsNullOrEmpty(eventCostStr) || 
                string.IsNullOrEmpty(eventImgSrc))
            {
                MessageBox.Show("Please fill in all fields", "Input Error",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!double.TryParse(eventCostStr, out double eventCost))
            {
                MessageBox.Show("Please enter a valid cost (numeric value)", "Input Error",
                                  MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string checkEvent = "SELECT COUNT(*) FROM Events WHERE EventName=@EventName AND EventDate=@EventDate;";
                    using (var cmd = new SQLiteCommand(checkEvent, connection))
                    {
                        AddEventParameters(cmd, eventName, eventDate, eventDesc, eventCost, eventImgSrc);
                        int Count = Convert.ToInt32(cmd.ExecuteScalar());
                        if (Count == 0)
                        {
                            string insertEvent = "INSERT INTO Events(EventName, EventDate, EventDesc, EventCost, EventImgSrc, TicketCount) VALUES (@EventName, @EventDate, @EventDesc, @EventCost, @EventImgSrc, 0);";
                            using (var insertCmd = new SQLiteCommand(insertEvent, connection))
                            {
                                AddEventParameters(insertCmd, eventName, eventDate, eventDesc, eventCost, eventImgSrc);
                                insertCmd.ExecuteNonQuery();
                            }
                            MessageBox.Show("Event Added Successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                            ClearForm();
                        }
                        else
                        {
                            MessageBox.Show("Event with this name and date already exists!", "Add Event failed", MessageBoxButton.OK, MessageBoxImage.Error);
                            ClearForm();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding event: " + ex.Message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Helper to avoid repeating AddWithValue calls
        private static void AddEventParameters(SQLiteCommand cmd, string eventName, string eventDate, string eventDesc, double eventCost, string eventImgSrc)
        {
            cmd.Parameters.AddWithValue("@EventName", eventName);
            cmd.Parameters.AddWithValue("@EventDate", eventDate);
            cmd.Parameters.AddWithValue("@EventDesc", eventDesc);
            cmd.Parameters.AddWithValue("@EventCost", eventCost);
            cmd.Parameters.AddWithValue("@EventImgSrc", eventImgSrc);
        }

        private void ClearForm()
        {
            txtEventName.Clear();
            txtEventDate.Clear();
            txtEventDesc.Clear();
            txtEventCost.Clear();
            txtEventImgSrc.Clear();
        }

        private void DeleteEvent_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (dataGridEvents.SelectedItem == null)
                {
                    MessageBox.Show("Please select an event record to delete", "No selection is made", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                DataRowView row = (DataRowView)dataGridEvents.SelectedItem;
                int eventID = Convert.ToInt32((row["EventID"]));

                MessageBoxResult result = MessageBox.Show(
                    "Are you sure you want to delete this event? This will also delete all related bookings.", 
                    "Confirm Deletion",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question
                    );

                if (result == MessageBoxResult.No)
                {
                    return;
                }

                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();
                    string deleteQuery = "DELETE FROM Events WHERE EventID = @EventID";
                    using (var cmd = new SQLiteCommand(deleteQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@EventID", eventID);
                        cmd.ExecuteNonQuery();

                        ViewTable_Click(null, null);
                        MessageBox.Show("Event deleted successfully", "Deleted", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting event: " + ex.Message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateEvent_Click(object sender, EventArgs e)
        {
            string eventName = txtEventName.Text.Trim();
            string eventDate = txtEventDate.Text.Trim();
            string eventDesc = txtEventDesc.Text.Trim();
            string eventCostStr = txtEventCost.Text.Trim();
            string eventImgSrc = txtEventImgSrc.Text.Trim();

            try
            {
                if (dataGridEvents.SelectedItem == null)
                {
                    MessageBox.Show("Please select an event record to update", "No selection is made", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (string.IsNullOrEmpty(eventName) || string.IsNullOrEmpty(eventDate) || 
                    string.IsNullOrEmpty(eventDesc) || string.IsNullOrEmpty(eventCostStr) || 
                    string.IsNullOrEmpty(eventImgSrc))
                {
                    MessageBox.Show("Please fill in all fields", "Input Error",
                                      MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (!double.TryParse(eventCostStr, out double eventCost))
                {
                    MessageBox.Show("Please enter a valid cost (numeric value)", "Input Error",
                                      MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                DataRowView row = (DataRowView)dataGridEvents.SelectedItem;
                int eventID = Convert.ToInt32((row["EventID"]));

                MessageBoxResult result = MessageBox.Show(
                    "Are you sure you want to update this event?", "Confirm update",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question
                    );

                if (result == MessageBoxResult.No)
                {
                    return;
                }

                string query = @"
                    UPDATE Events
                     SET EventName = @EventName,
                     EventDate = @EventDate,
                     EventDesc = @EventDesc,
                     EventCost = @EventCost,
                     EventImgSrc = @EventImgSrc
                     WHERE EventID = @EventID";

                using (var conn = new SQLiteConnection(connectionString))
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    AddEventParameters(cmd, eventName, eventDate, eventDesc, eventCost, eventImgSrc);
                    cmd.Parameters.AddWithValue("@EventID", eventID);
                    conn.Open();
                    int rows = cmd.ExecuteNonQuery();

                    if (rows > 0)
                    {
                        MessageBox.Show("Event updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        ViewTable_Click(null, null);
                        ClearForm();
                    }
                    else
                    {
                        MessageBox.Show("No event was updated. Please check your selection.", "Update Failed", MessageBoxButton.OK, MessageBoxImage.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating event: " + ex.Message, "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void dataGridEvents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dataGridEvents.SelectedItem != null)
            {
                DataRowView row = (DataRowView)dataGridEvents.SelectedItem;
                txtEventName.Text = row["EventName"]?.ToString() ?? "";
                txtEventDate.Text = row["EventDate"]?.ToString() ?? "";
                txtEventDesc.Text = row["EventDesc"]?.ToString() ?? "";
                txtEventCost.Text = row["EventCost"]?.ToString() ?? "";
                txtEventImgSrc.Text = row["EventImgSrc"]?.ToString() ?? "";
            }
        }
    }
}
